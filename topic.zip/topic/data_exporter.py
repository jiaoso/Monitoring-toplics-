#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
话题数据导出工具
用于将监视器收集的数据导出为CSV或JSON格式
"""

import json
import csv
import os
from datetime import datetime
from typing import List, Dict, Any

class TopicDataExporter:
    """话题数据导出器"""
    
    def __init__(self):
        self.data_history = []
        
    def add_data_point(self, topic: str, timestamp: str, data: str, slot_id: int):
        """添加数据点"""
        self.data_history.append({
            'timestamp': timestamp,
            'topic': topic,
            'slot_id': slot_id,
            'data': data
        })
    
    def export_to_csv(self, filename: str = None) -> str:
        """导出为CSV格式"""
        if filename is None:
            filename = f"topic_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['timestamp', 'topic', 'slot_id', 'data']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for record in self.data_history:
                writer.writerow(record)
        
        return filename
    
    def export_to_json(self, filename: str = None) -> str:
        """导出为JSON格式"""
        if filename is None:
            filename = f"topic_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        export_data = {
            'export_time': datetime.now().isoformat(),
            'total_records': len(self.data_history),
            'data': self.data_history
        }
        
        with open(filename, 'w', encoding='utf-8') as jsonfile:
            json.dump(export_data, jsonfile, indent=2, ensure_ascii=False)
        
        return filename
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取数据统计"""
        if not self.data_history:
            return {'total_records': 0}
        
        topics = set(record['topic'] for record in self.data_history)
        slots = set(record['slot_id'] for record in self.data_history)
        
        topic_counts = {}
        for record in self.data_history:
            topic = record['topic']
            topic_counts[topic] = topic_counts.get(topic, 0) + 1
        
        return {
            'total_records': len(self.data_history),
            'unique_topics': len(topics),
            'active_slots': len(slots),
            'topics_list': list(topics),
            'topic_message_counts': topic_counts,
            'first_record': self.data_history[0]['timestamp'] if self.data_history else None,
            'last_record': self.data_history[-1]['timestamp'] if self.data_history else None
        }
    
    def clear_data(self):
        """清除所有数据"""
        self.data_history.clear()

def create_sample_data():
    """创建示例数据用于测试"""
    exporter = TopicDataExporter()
    
    # 添加一些示例数据
    sample_topics = ["/sensor/camera", "/cmd_vel", "/robot/pose"]
    
    for i in range(50):
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        topic = sample_topics[i % len(sample_topics)]
        slot_id = i % 3
        data = f"示例数据 {i}: 数值={i*2.5:.2f}"
        
        exporter.add_data_point(topic, timestamp, data, slot_id)
    
    return exporter

def main():
    """主函数 - 演示导出功能"""
    print("话题数据导出工具演示")
    print("=" * 40)
    
    # 创建示例数据
    print("创建示例数据...")
    exporter = create_sample_data()
    
    # 显示统计信息
    stats = exporter.get_statistics()
    print(f"\n数据统计:")
    print(f"  总记录数: {stats['total_records']}")
    print(f"  话题数量: {stats['unique_topics']}")
    print(f"  活跃槽位: {stats['active_slots']}")
    print(f"  话题列表: {', '.join(stats['topics_list'])}")
    
    # 导出为CSV
    print(f"\n导出为CSV格式...")
    csv_file = exporter.export_to_csv()
    print(f"  已保存为: {csv_file}")
    
    # 导出为JSON
    print(f"\n导出为JSON格式...")
    json_file = exporter.export_to_json()
    print(f"  已保存为: {json_file}")
    
    print(f"\n导出完成！")
    print(f"生成的文件:")
    print(f"  - {csv_file}")
    print(f"  - {json_file}")

if __name__ == "__main__":
    main()
