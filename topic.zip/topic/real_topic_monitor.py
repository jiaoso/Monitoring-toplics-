#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
真实话题监视器 - Real Topic Monitor
功能：
1. 监视真实的ROS话题（不使用模拟数据）
2. 自动发现在线话题
3. 保存话题内容到本地文件
4. 支持多种话题类型
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import time
import json
import os
import subprocess
import re
from datetime import datetime
from typing import Dict, List, Optional


class RealTopicMonitor:
    def __init__(self, root):
        self.root = root
        self.root.title("真实话题监视器 v2.0")
        self.root.geometry("1400x800")
        self.root.configure(bg='#f0f0f0')
        
        # 配置文件路径
        self.config_file = "monitor_config.json"
        self.save_directory = "话题信息存储"
        
        # 确保保存目录存在
        os.makedirs(self.save_directory, exist_ok=True)
        
        # 数据存储
        self.online_topics = []
        self.monitor_slots = {}
        self.topic_data = {}
        self.running = True
        self.selected_topic = None
        
        # 话题保存状态
        self.saving_topics = {}  # {slot_id: bool}
        
        # 统计信息
        self.stats = {
            'total_messages': 0,
            'start_time': datetime.now()
        }
        
        # 检查ROS环境
        self.ros_available = self.check_ros_environment()
        
        # 创建GUI
        self.setup_gui()
        
        # 加载配置
        self.load_config()
        
        # 启动后台线程
        self.start_background_threads()
    
    def check_ros_environment(self):
        """检查ROS环境是否可用"""
        print("检查ROS环境...")
        
        # 检查rostopic命令是否存在
        try:
            result = subprocess.run(['which', 'rostopic'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                print("✓ 找到 rostopic 命令")
                # 进一步测试rostopic是否能正常工作
                try:
                    test_result = subprocess.run(['rostopic', 'list'], 
                                               capture_output=True, text=True, timeout=10)
                    if test_result.returncode == 0:
                        print("✓ rostopic 命令可正常使用")
                        return True
                    else:
                        print(f"✗ rostopic 命令执行失败: {test_result.stderr}")
                except Exception as e:
                    print(f"✗ rostopic 测试异常: {e}")
        except Exception as e:
            print(f"✗ rostopic 检查异常: {e}")
        
        # 检查ros2命令是否存在
        try:
            result = subprocess.run(['which', 'ros2'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                print("✓ 找到 ros2 命令")
                # 进一步测试ros2是否能正常工作
                try:
                    test_result = subprocess.run(['ros2', 'topic', 'list'], 
                                               capture_output=True, text=True, timeout=10)
                    if test_result.returncode == 0:
                        print("✓ ros2 命令可正常使用")
                        return True
                    else:
                        print(f"✗ ros2 命令执行失败: {test_result.stderr}")
                except Exception as e:
                    print(f"✗ ros2 测试异常: {e}")
        except Exception as e:
            print(f"✗ ros2 检查异常: {e}")
        
        print("✗ 未检测到可用的ROS环境")
        return False
    
    def setup_gui(self):
        """设置GUI界面"""
        # 创建菜单栏
        self.create_menu()
        
        # 主框架
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 显示ROS状态
        self.create_ros_status_bar(main_frame)
        
        # 创建左侧在线话题列表
        self.create_online_topics_panel(main_frame)
        
        # 创建监视框区域
        self.create_monitor_panels(main_frame)
        
        # 创建状态栏
        self.create_status_bar()
    
    def create_ros_status_bar(self, parent):
        """创建ROS状态栏"""
        status_frame = tk.Frame(parent, bg='#e8f4fd', relief=tk.RAISED, bd=1)
        status_frame.pack(fill=tk.X, pady=(0, 10))
        
        if self.ros_available:
            status_text = "✓ ROS环境已检测到 - 可以监视真实话题"
            bg_color = '#d4edda'
            fg_color = '#155724'
        else:
            status_text = "⚠ 未检测到ROS环境 - 将使用示例话题进行演示"
            bg_color = '#fff3cd'
            fg_color = '#856404'
        
        status_frame.config(bg=bg_color)
        status_label = tk.Label(status_frame, text=status_text,
                               bg=bg_color, fg=fg_color,
                               font=('微软雅黑', 10, 'bold'),
                               pady=5)
        status_label.pack()
    
    def create_menu(self):
        """创建菜单栏"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # 文件菜单
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="文件", menu=file_menu)
        file_menu.add_command(label="保存配置", command=self.save_config)
        file_menu.add_command(label="加载配置", command=self.load_config)
        file_menu.add_separator()
        file_menu.add_command(label="打开保存目录", command=self.open_save_directory)
        file_menu.add_separator()
        file_menu.add_command(label="退出", command=self.on_closing)
        
        # 工具菜单
        tools_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="工具", menu=tools_menu)
        tools_menu.add_command(label="清除所有绑定", command=self.clear_all_bindings)
        tools_menu.add_command(label="刷新话题列表", command=self.force_refresh_topics)
        tools_menu.add_command(label="统计信息", command=self.show_statistics)
        tools_menu.add_separator()
        tools_menu.add_command(label="清理保存文件", command=self.cleanup_saved_files)
        
        # 帮助菜单
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="帮助", menu=help_menu)
        help_menu.add_command(label="使用说明", command=self.show_help)
        help_menu.add_command(label="关于", command=self.show_about)
    
    def create_status_bar(self):
        """创建状态栏"""
        self.status_frame = tk.Frame(self.root, bg='#e0e0e0', relief=tk.SUNKEN, bd=1)
        self.status_frame.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.status_label = tk.Label(self.status_frame, text="就绪", 
                                    bg='#e0e0e0', anchor=tk.W,
                                    font=('微软雅黑', 9))
        self.status_label.pack(side=tk.LEFT, padx=5)
        
        self.stats_label = tk.Label(self.status_frame, text="消息: 0", 
                                   bg='#e0e0e0', anchor=tk.E,
                                   font=('微软雅黑', 9))
        self.stats_label.pack(side=tk.RIGHT, padx=5)
    
    def create_online_topics_panel(self, parent):
        """创建左侧在线话题面板"""
        left_frame = tk.Frame(parent, bg='#f0f0f0', width=250)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left_frame.pack_propagate(False)
        
        # 标题
        title_label = tk.Label(left_frame, text="当前存在话题", 
                              font=('微软雅黑', 14, 'bold'), 
                              bg='#f0f0f0')
        title_label.pack(pady=(0, 10))
        
        # 搜索框
        search_frame = tk.Frame(left_frame, bg='#f0f0f0')
        search_frame.pack(fill=tk.X, pady=(0, 5))
        
        tk.Label(search_frame, text="搜索:", font=('微软雅黑', 9), 
                bg='#f0f0f0').pack(side=tk.LEFT)
        
        self.search_var = tk.StringVar()
        self.search_var.trace('w', self.filter_topics)
        search_entry = tk.Entry(search_frame, textvariable=self.search_var,
                               font=('微软雅黑', 9))
        search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        
        # 话题列表框
        list_frame = tk.Frame(left_frame, bg='white', relief=tk.SUNKEN, bd=2)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.topics_listbox = tk.Listbox(list_frame, 
                                        yscrollcommand=scrollbar.set,
                                        font=('微软雅黑', 10),
                                        selectmode=tk.SINGLE)
        self.topics_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.topics_listbox.yview)
        
        self.topics_listbox.bind('<Double-Button-1>', self.on_topic_select)
        self.topics_listbox.bind('<Button-1>', self.on_topic_click)
        
        # 刷新按钮
        refresh_btn = tk.Button(left_frame, text="刷新话题列表",
                               command=self.force_refresh_topics,
                               font=('微软雅黑', 9),
                               bg='#007bff', fg='white')
        refresh_btn.pack(fill=tk.X, pady=(5, 0))
    
    def create_monitor_panels(self, parent):
        """创建监视面板区域"""
        right_frame = tk.Frame(parent, bg='#f0f0f0')
        right_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # 标题
        title_label = tk.Label(right_frame, text="话题监视区域 (最多10个)", 
                              font=('微软雅黑', 14, 'bold'), 
                              bg='#f0f0f0')
        title_label.pack(pady=(0, 10))
        
        # 创建滚动区域
        canvas = tk.Canvas(right_frame, bg='#f0f0f0')
        scrollbar_v = tk.Scrollbar(right_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg='#f0f0f0')
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar_v.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar_v.pack(side="right", fill="y")
        
        # 创建10个监视槽位
        self.monitor_frames = {}
        self.status_indicators = {}
        self.frequency_vars = {}
        self.data_displays = {}
        self.control_buttons = {}
        self.save_buttons = {}
        
        for i in range(10):
            self.create_single_monitor_panel(scrollable_frame, i)
    
    def create_single_monitor_panel(self, parent, slot_id):
        """创建单个监视面板"""
        panel_frame = tk.Frame(parent, bg='white', relief=tk.RAISED, bd=2)
        panel_frame.pack(fill=tk.X, pady=5, padx=5)
        
        # 槽位编号
        slot_label = tk.Label(panel_frame, text=f"#{slot_id + 1}", 
                             font=('微软雅黑', 12, 'bold'),
                             bg='white', fg='#666')
        slot_label.pack(side=tk.LEFT, padx=5)
        
        # 话题显示框
        topic_frame = tk.Frame(panel_frame, bg='white', width=180)
        topic_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
        topic_frame.pack_propagate(False)
        
        topic_label = tk.Label(topic_frame, text=f"话题槽位 {slot_id + 1}", 
                              font=('微软雅黑', 10),
                              bg='#f8f8f8', relief=tk.SUNKEN, bd=1,
                              wraplength=170)
        topic_label.pack(fill=tk.BOTH, expand=True)
        
        # 控制按钮
        btn_frame = tk.Frame(panel_frame, bg='white')
        btn_frame.pack(side=tk.LEFT, padx=5)
        
        control_btn = tk.Button(btn_frame, text="确定", 
                               command=lambda: self.toggle_binding(slot_id),
                               font=('微软雅黑', 9),
                               width=6, height=1,
                               bg='#4CAF50', fg='white')
        control_btn.pack(pady=1)
        self.control_buttons[slot_id] = control_btn
        
        # 保存按钮
        save_btn = tk.Button(btn_frame, text="保存", 
                            command=lambda: self.toggle_saving(slot_id),
                            font=('微软雅黑', 9),
                            width=6, height=1,
                            bg='#ff9800', fg='white',
                            state=tk.DISABLED)
        save_btn.pack(pady=1)
        self.save_buttons[slot_id] = save_btn
        
        # 状态指示器
        status_frame = tk.Frame(panel_frame, bg='white')
        status_frame.pack(side=tk.LEFT, padx=5)
        
        status_indicator = tk.Label(status_frame, text="●", 
                                   font=('微软雅黑', 24),
                                   fg='gray', bg='white')
        status_indicator.pack()
        self.status_indicators[slot_id] = status_indicator
        
        # 频率设置
        freq_frame = tk.Frame(panel_frame, bg='white')
        freq_frame.pack(side=tk.LEFT, padx=5)
        
        tk.Label(freq_frame, text="频率(Hz):", 
                font=('微软雅黑', 9), bg='white').pack()
        
        freq_var = tk.StringVar(value="1.0")
        freq_entry = tk.Entry(freq_frame, textvariable=freq_var, 
                             width=8, font=('微软雅黑', 9))
        freq_entry.pack()
        freq_entry.bind('<Return>', lambda e: self.update_frequency(slot_id))
        self.frequency_vars[slot_id] = freq_var
        
        # 消息计数
        count_label = tk.Label(freq_frame, text="消息: 0", 
                              font=('微软雅黑', 8), bg='white', fg='#666')
        count_label.pack()
        
        # 保存状态
        save_status_label = tk.Label(freq_frame, text="", 
                                    font=('微软雅黑', 8), bg='white', fg='#666')
        save_status_label.pack()
        
        # 数据显示区域
        data_frame = tk.Frame(panel_frame, bg='white')
        data_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        
        # 添加滚动条到数据显示
        data_scroll = tk.Scrollbar(data_frame)
        data_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        data_text = tk.Text(data_frame, height=4, width=50,
                           font=('Consolas', 8),
                           wrap=tk.WORD, state=tk.DISABLED,
                           yscrollcommand=data_scroll.set)
        data_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        data_scroll.config(command=data_text.yview)
        
        self.data_displays[slot_id] = data_text
        
        # 存储引用
        self.monitor_frames[slot_id] = {
            'frame': panel_frame,
            'topic_label': topic_label,
            'count_label': count_label,
            'save_status_label': save_status_label,
            'bound_topic': None,
            'message_count': 0,
            'save_file': None
        }
        
        # 初始化保存状态
        self.saving_topics[slot_id] = False
    
    def discover_ros_topics(self):
        """发现真实的ROS话题"""
        topics = []
        
        if not self.ros_available:
            # 如果没有ROS环境，返回空列表，不使用示例话题
            return []
        
        try:
            # 尝试ROS1
            result = subprocess.run(['rostopic', 'list'], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                topics = [line.strip() for line in result.stdout.split('\n') if line.strip()]
                return topics
        except Exception:
            pass
        
        try:
            # 尝试ROS2
            result = subprocess.run(['ros2', 'topic', 'list'], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                topics = [line.strip() for line in result.stdout.split('\n') if line.strip()]
                return topics
        except Exception:
            pass
        
        return topics
    
    def get_topic_data(self, topic_name):
        """获取真实话题数据"""
        if not self.ros_available:
            return None  # 不生成任何模拟数据
        
        try:
            # 尝试ROS1 - 增加超时时间
            result = subprocess.run(['rostopic', 'echo', '-n', '1', topic_name], 
                                  capture_output=True, text=True, timeout=3)
            if result.returncode == 0 and result.stdout.strip():
                timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
                data = result.stdout.strip()[:500]  # 增加数据长度限制
                return f"[{timestamp}] {data}"
        except Exception:
            pass  # 静默处理错误
        
        try:
            # 尝试ROS2 - 增加超时时间以获取更多真实数据
            result = subprocess.run(['ros2', 'topic', 'echo', '--once', topic_name], 
                                  capture_output=True, text=True, timeout=4)
            if result.returncode == 0 and result.stdout.strip():
                timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
                data = result.stdout.strip()[:500]  # 增加数据长度限制
                return f"[{timestamp}] {data}"
        except Exception:
            pass  # 静默处理错误
        
        # 如果无法获取真实数据，返回None（不生成模拟数据）
        return None
    
    def filter_topics(self, *args):
        """过滤话题列表"""
        search_term = self.search_var.get().lower()
        self.topics_listbox.delete(0, tk.END)
        
        filtered_topics = [topic for topic in sorted(self.online_topics) 
                          if search_term in topic.lower()]
        
        for topic in filtered_topics:
            self.topics_listbox.insert(tk.END, topic)
    
    def on_topic_click(self, event):
        """话题点击事件"""
        selection = self.topics_listbox.curselection()
        if selection:
            topic_name = self.topics_listbox.get(selection[0])
            self.selected_topic = topic_name
            self.update_status(f"已选择话题: {topic_name}")
    
    def on_topic_select(self, event):
        """话题双击事件"""
        self.on_topic_click(event)
        if self.selected_topic:
            messagebox.showinfo("提示", 
                               f"已选择话题: {self.selected_topic}\n"
                               "请点击要绑定的话题框右侧的'确定'按钮")
    
    def toggle_binding(self, slot_id):
        """切换话题绑定"""
        if self.monitor_frames[slot_id]['bound_topic'] is None:
            if self.selected_topic:
                self.bind_topic_to_slot(slot_id, self.selected_topic)
            else:
                messagebox.showwarning("警告", "请先从左侧话题列表中选择一个话题")
        else:
            self.unbind_topic_from_slot(slot_id)
    
    def bind_topic_to_slot(self, slot_id, topic_name):
        """绑定话题到槽位"""
        # 检查是否已经绑定到其他槽位
        for sid, info in self.monitor_frames.items():
            if info['bound_topic'] == topic_name:
                messagebox.showwarning("警告", f"话题 {topic_name} 已经绑定到槽位 {sid + 1}")
                return
        
        # 绑定话题
        self.monitor_frames[slot_id]['bound_topic'] = topic_name
        self.monitor_frames[slot_id]['topic_label'].config(text=topic_name)
        self.monitor_frames[slot_id]['message_count'] = 0
        self.control_buttons[slot_id].config(text="取消", bg='#f44336')
        self.save_buttons[slot_id].config(state=tk.NORMAL)
        
        # 初始化监视槽位
        self.monitor_slots[slot_id] = {
            'topic': topic_name,
            'frequency': float(self.frequency_vars[slot_id].get() or 1.0),
            'last_update': time.time(),
            'data_count': 0
        }
        
        self.update_status(f"话题 {topic_name} 已绑定到槽位 {slot_id + 1}")
    
    def unbind_topic_from_slot(self, slot_id):
        """解绑话题"""
        topic_name = self.monitor_frames[slot_id]['bound_topic']
        
        # 停止保存
        if self.saving_topics[slot_id]:
            self.stop_saving(slot_id)
        
        # 解绑
        self.monitor_frames[slot_id]['bound_topic'] = None
        self.monitor_frames[slot_id]['topic_label'].config(text=f"话题槽位 {slot_id + 1}")
        self.monitor_frames[slot_id]['message_count'] = 0
        self.monitor_frames[slot_id]['count_label'].config(text="消息: 0")
        self.monitor_frames[slot_id]['save_status_label'].config(text="")
        self.control_buttons[slot_id].config(text="确定", bg='#4CAF50')
        self.save_buttons[slot_id].config(state=tk.DISABLED, text="保存", bg='#ff9800')
        self.status_indicators[slot_id].config(fg='gray')
        
        # 清除监视数据
        if slot_id in self.monitor_slots:
            del self.monitor_slots[slot_id]
        
        # 清除数据显示
        self.data_displays[slot_id].config(state=tk.NORMAL)
        self.data_displays[slot_id].delete(1.0, tk.END)
        self.data_displays[slot_id].config(state=tk.DISABLED)
        
        self.update_status(f"话题 {topic_name} 已从槽位 {slot_id + 1} 解绑")
    
    def toggle_saving(self, slot_id):
        """切换保存状态"""
        if self.saving_topics[slot_id]:
            self.stop_saving(slot_id)
        else:
            self.start_saving(slot_id)
    
    def start_saving(self, slot_id):
        """开始保存话题数据"""
        topic_name = self.monitor_frames[slot_id]['bound_topic']
        if not topic_name:
            return
        
        # 生成文件名
        topic_short = topic_name.replace('/', '_').replace(' ', '_')
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{topic_short}_{timestamp}.txt"
        filepath = os.path.join(self.save_directory, filename)
        
        try:
            # 创建保存文件
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(f"话题数据保存文件\n")
                f.write(f"话题名称: {topic_name}\n")
                f.write(f"开始时间: {datetime.now().isoformat()}\n")
                f.write(f"{'='*50}\n\n")
            
            self.monitor_frames[slot_id]['save_file'] = filepath
            self.saving_topics[slot_id] = True
            self.save_buttons[slot_id].config(text="停止", bg='#dc3545')
            self.monitor_frames[slot_id]['save_status_label'].config(text="保存中", fg='green')
            
            self.update_status(f"开始保存 {topic_name} 到 {filename}")
            
        except Exception as e:
            messagebox.showerror("错误", f"无法创建保存文件: {e}")
    
    def stop_saving(self, slot_id):
        """停止保存话题数据"""
        if slot_id in self.monitor_frames and self.monitor_frames[slot_id]['save_file']:
            try:
                # 写入结束信息
                with open(self.monitor_frames[slot_id]['save_file'], 'a', encoding='utf-8') as f:
                    f.write(f"\n{'='*50}\n")
                    f.write(f"结束时间: {datetime.now().isoformat()}\n")
                    f.write(f"总消息数: {self.monitor_frames[slot_id]['message_count']}\n")
            except Exception as e:
                print(f"保存结束信息时出错: {e}")
        
        self.saving_topics[slot_id] = False
        self.monitor_frames[slot_id]['save_file'] = None
        self.save_buttons[slot_id].config(text="保存", bg='#ff9800')
        self.monitor_frames[slot_id]['save_status_label'].config(text="", fg='black')
        
        topic_name = self.monitor_frames[slot_id]['bound_topic']
        self.update_status(f"停止保存 {topic_name}")
    
    def save_topic_data(self, slot_id, data):
        """保存话题数据到文件"""
        if self.saving_topics[slot_id] and self.monitor_frames[slot_id]['save_file']:
            try:
                with open(self.monitor_frames[slot_id]['save_file'], 'a', encoding='utf-8') as f:
                    f.write(data + '\n')
            except Exception as e:
                print(f"保存数据时出错: {e}")
                self.stop_saving(slot_id)
    
    def update_frequency(self, slot_id):
        """更新监视频率"""
        if slot_id in self.monitor_slots:
            try:
                freq = float(self.frequency_vars[slot_id].get() or 1.0)
                self.monitor_slots[slot_id]['frequency'] = freq
                self.update_status(f"槽位 {slot_id + 1} 频率已更新为 {freq} Hz")
            except ValueError:
                messagebox.showerror("错误", "请输入有效的频率值")
                self.frequency_vars[slot_id].set("1.0")
    
    def update_online_topics(self):
        """更新在线话题列表"""
        while self.running:
            try:
                new_online_topics = self.discover_ros_topics()
                
                if new_online_topics != self.online_topics:
                    self.online_topics = new_online_topics
                    self.root.after(0, self.refresh_topics_list)
                
                time.sleep(5)  # 每5秒检查一次
            except Exception as e:
                print(f"更新在线话题时出错: {e}")
                time.sleep(5)
    
    def refresh_topics_list(self):
        """刷新话题列表显示"""
        self.filter_topics()
    
    def monitor_topics(self):
        """监视话题数据"""
        while self.running:
            try:
                current_time = time.time()
                
                for slot_id, slot_info in self.monitor_slots.copy().items():
                    topic = slot_info['topic']
                    frequency = float(self.frequency_vars[slot_id].get() or 1.0)
                    
                    if current_time - slot_info['last_update'] >= 1.0 / frequency:
                        # 检查话题是否在线
                        is_online = topic in self.online_topics
                        color = '#00ff00' if is_online else '#ff0000'
                        
                        self.root.after(0, lambda sid=slot_id, c=color: 
                                       self.status_indicators[sid].config(fg=c))
                        
                        if is_online:
                            # 尝试获取真实数据
                            data = self.get_topic_data(topic)
                            
                            # 更新时间（无论是否获取到数据）
                            slot_info['last_update'] = current_time
                            
                            if data:
                                # 有真实数据时处理
                                self.root.after(0, lambda sid=slot_id, d=data: 
                                               self.update_data_display(sid, d))
                                
                                # 保存数据
                                if self.saving_topics[slot_id]:
                                    self.save_topic_data(slot_id, data)
                                
                                slot_info['data_count'] += 1
                                
                                # 更新消息计数（只计算成功获取的数据）
                                self.monitor_frames[slot_id]['message_count'] += 1
                                count = self.monitor_frames[slot_id]['message_count']
                                self.root.after(0, lambda sid=slot_id, c=count:
                                               self.monitor_frames[sid]['count_label'].config(
                                                   text=f"消息: {c}"))
                                
                                # 更新全局统计
                                self.stats['total_messages'] += 1
                                self.root.after(0, self.update_statistics_display)
                            else:
                                # 没有真实数据时，显示等待状态（但不保存）
                                self.root.after(0, lambda sid=slot_id: 
                                               self.update_data_display(sid, f"[{datetime.now().strftime('%H:%M:%S')}] 尝试获取数据..."))
                
                time.sleep(0.1)  # 10Hz检查频率
            except Exception as e:
                print(f"监视话题时出错: {e}")
                time.sleep(1)
    
    def update_data_display(self, slot_id, data):
        """更新数据显示"""
        try:
            text_widget = self.data_displays[slot_id]
            text_widget.config(state=tk.NORMAL)
            
            text_widget.insert(tk.END, data + "\n")
            
            # 限制显示行数
            lines = text_widget.get(1.0, tk.END).strip().split('\n')
            if len(lines) > 15:
                text_widget.delete(1.0, tk.END)
                text_widget.insert(1.0, '\n'.join(lines[-15:]) + '\n')
            
            text_widget.see(tk.END)
            text_widget.config(state=tk.DISABLED)
        except Exception as e:
            print(f"更新数据显示时出错: {e}")
    
    def update_status(self, message):
        """更新状态栏"""
        self.status_label.config(text=message)
        self.root.after(3000, lambda: self.status_label.config(text="就绪"))
    
    def update_statistics_display(self):
        """更新统计显示"""
        self.stats_label.config(text=f"消息: {self.stats['total_messages']}")
    
    def open_save_directory(self):
        """打开保存目录"""
        try:
            if os.name == 'nt':  # Windows
                os.startfile(self.save_directory)
            elif os.name == 'posix':  # Linux/Mac
                subprocess.run(['xdg-open', self.save_directory])
        except Exception as e:
            messagebox.showerror("错误", f"无法打开目录: {e}")
    
    def cleanup_saved_files(self):
        """清理保存的文件"""
        try:
            files = os.listdir(self.save_directory)
            if not files:
                messagebox.showinfo("信息", "保存目录为空")
                return
            
            if messagebox.askyesno("确认", f"确定要删除保存目录中的 {len(files)} 个文件吗？"):
                for file in files:
                    file_path = os.path.join(self.save_directory, file)
                    if os.path.isfile(file_path):
                        os.remove(file_path)
                messagebox.showinfo("完成", "文件清理完成")
        except Exception as e:
            messagebox.showerror("错误", f"清理文件时出错: {e}")
    
    def save_config(self):
        """保存配置"""
        config = {
            'bindings': {},
            'frequencies': {}
        }
        
        for slot_id, frame_info in self.monitor_frames.items():
            if frame_info['bound_topic']:
                config['bindings'][slot_id] = frame_info['bound_topic']
                config['frequencies'][slot_id] = self.frequency_vars[slot_id].get()
        
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            self.update_status("配置已保存")
        except Exception as e:
            messagebox.showerror("错误", f"保存配置失败: {e}")
    
    def load_config(self):
        """加载配置"""
        if not os.path.exists(self.config_file):
            return
        
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            # 等待话题列表加载完成
            self.root.after(2000, lambda: self.apply_config(config))
            
        except Exception as e:
            messagebox.showerror("错误", f"加载配置失败: {e}")
    
    def apply_config(self, config):
        """应用配置"""
        try:
            # 恢复绑定
            for slot_id_str, topic in config.get('bindings', {}).items():
                slot_id = int(slot_id_str)
                if topic in self.online_topics:
                    self.selected_topic = topic
                    self.bind_topic_to_slot(slot_id, topic)
            
            # 恢复频率设置
            for slot_id_str, freq in config.get('frequencies', {}).items():
                slot_id = int(slot_id_str)
                self.frequency_vars[slot_id].set(freq)
            
            self.update_status("配置已加载")
        except Exception as e:
            print(f"应用配置时出错: {e}")
    
    def clear_all_bindings(self):
        """清除所有绑定"""
        if messagebox.askyesno("确认", "确定要清除所有话题绑定吗？"):
            for slot_id in list(self.monitor_frames.keys()):
                if self.monitor_frames[slot_id]['bound_topic']:
                    self.unbind_topic_from_slot(slot_id)
            self.update_status("已清除所有绑定")
    
    def force_refresh_topics(self):
        """强制刷新话题列表"""
        self.update_status("正在刷新话题列表...")
        threading.Thread(target=self._refresh_topics_thread, daemon=True).start()
    
    def _refresh_topics_thread(self):
        """刷新话题的后台线程"""
        try:
            new_topics = self.discover_ros_topics()
            self.online_topics = new_topics
            self.root.after(0, self.refresh_topics_list)
            self.root.after(0, lambda: self.update_status("话题列表已刷新"))
        except Exception as e:
            self.root.after(0, lambda: self.update_status(f"刷新失败: {e}"))
    
    def show_statistics(self):
        """显示统计信息"""
        runtime = datetime.now() - self.stats['start_time']
        bound_topics = sum(1 for info in self.monitor_frames.values() 
                          if info['bound_topic'] is not None)
        saving_count = sum(1 for saving in self.saving_topics.values() if saving)
        
        stats_text = f"""运行统计信息:
        
运行时间: {runtime}
ROS环境: {'可用' if self.ros_available else '不可用'}
在线话题数: {len(self.online_topics)}
已绑定槽位: {bound_topics}/10
正在保存: {saving_count}个话题
总接收消息: {self.stats['total_messages']}
平均消息速率: {self.stats['total_messages'] / max(runtime.total_seconds(), 1):.2f} 消息/秒"""
        
        messagebox.showinfo("统计信息", stats_text)
    
    def show_help(self):
        """显示帮助信息"""
        help_text = """真实话题监视器使用说明:

1. 话题选择: 在左侧话题列表中点击选择话题
2. 绑定话题: 选择话题后，点击右侧槽位的"确定"按钮
3. 设置频率: 在频率输入框中设置监视频率(Hz)
4. 保存数据: 点击"保存"按钮开始保存话题数据到文件
5. 查看数据: 绑定后右侧会显示实时数据
6. 解绑话题: 点击已绑定槽位的"取消"按钮

状态指示器说明:
● 灰色: 未绑定
● 绿色: 在线
● 红色: 离线

保存功能:
- 数据保存在"话题信息存储"文件夹
- 文件名格式: 话题简称_时间.txt
- 可通过"文件"菜单打开保存目录

注意:
- 需要ROS环境才能监视真实话题
- 无ROS环境时会显示示例话题"""
        
        messagebox.showinfo("使用说明", help_text)
    
    def show_about(self):
        """显示关于信息"""
        about_text = f"""真实话题监视器 v2.0

功能特性:
✓ 监视真实ROS话题
✓ 自动发现在线话题
✓ 话题数据保存
✓ 实时状态显示
✓ 可调监视频率
✓ 配置保存/加载
✓ 数据统计

ROS环境: {'✓ 已检测到' if self.ros_available else '✗ 未检测到'}
支持: ROS1 (rostopic) 和 ROS2 (ros2 topic)

技术: Python + tkinter + ROS命令行工具"""
        
        messagebox.showinfo("关于", about_text)
    
    def start_background_threads(self):
        """启动后台线程"""
        topic_thread = threading.Thread(target=self.update_online_topics, daemon=True)
        topic_thread.start()
        
        monitor_thread = threading.Thread(target=self.monitor_topics, daemon=True)
        monitor_thread.start()
    
    def on_closing(self):
        """关闭程序时的清理"""
        # 停止所有保存
        for slot_id in self.saving_topics:
            if self.saving_topics[slot_id]:
                self.stop_saving(slot_id)
        
        self.save_config()  # 自动保存配置
        self.running = False
        self.root.quit()
        self.root.destroy()


def main():
    """主函数"""
    root = tk.Tk()
    app = RealTopicMonitor(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()


if __name__ == "__main__":
    main()
