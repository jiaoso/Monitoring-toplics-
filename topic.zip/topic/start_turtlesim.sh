#!/bin/bash

# 启动turtlesim模拟器以提供真实的ROS话题数据

echo "启动 turtlesim 节点..."

# 检查ROS2环境
if command -v ros2 &> /dev/null; then
    echo "使用 ROS2 启动 turtlesim"
    
    # 启动turtlesim节点
    ros2 run turtlesim turtlesim_node &
    TURTLESIM_PID=$!
    
    sleep 2
    
    # 启动键盘控制节点
    echo "启动键盘控制节点（使用方向键控制小乌龟）"
    ros2 run turtlesim turtle_teleop_key &
    TELEOP_PID=$!
    
    echo "turtlesim 已启动！"
    echo "现在你可以："
    echo "1. 使用方向键控制小乌龟移动"
    echo "2. 运行话题监视器查看真实数据"
    echo "3. 按 Ctrl+C 停止所有节点"
    
    # 等待用户中断
    trap "echo '正在停止所有节点...'; kill $TURTLESIM_PID $TELEOP_PID 2>/dev/null; exit" INT
    wait
    
elif command -v roscore &> /dev/null; then
    echo "使用 ROS1 启动 turtlesim"
    
    # 启动roscore
    roscore &
    ROSCORE_PID=$!
    sleep 3
    
    # 启动turtlesim节点
    rosrun turtlesim turtlesim_node &
    TURTLESIM_PID=$!
    
    sleep 2
    
    # 启动键盘控制节点
    echo "启动键盘控制节点（使用方向键控制小乌龟）"
    rosrun turtlesim turtle_teleop_key &
    TELEOP_PID=$!
    
    echo "turtlesim 已启动！"
    echo "现在你可以："
    echo "1. 使用方向键控制小乌龟移动"
    echo "2. 运行话题监视器查看真实数据"
    echo "3. 按 Ctrl+C 停止所有节点"
    
    # 等待用户中断
    trap "echo '正在停止所有节点...'; kill $ROSCORE_PID $TURTLESIM_PID $TELEOP_PID 2>/dev/null; exit" INT
    wait
    
else
    echo "错误: 未找到 ROS 环境"
    echo "请确保已安装并配置 ROS1 或 ROS2"
    exit 1
fi
