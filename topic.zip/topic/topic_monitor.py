#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
话题监视器 - Topic Monitor
功能：
1. 自定义监视话题，最大监视数量10个
2. 左边自动检测当前所有在线的话题
3. 中左选择话题，绑定到监视框
4. 实时显示话题在线状态和数据
"""

import tkinter as tk
from tkinter import ttk, messagebox
import threading
import time
import random
import json
from datetime import datetime
from typing import Dict, List, Optional


class TopicMonitor:
    def __init__(self, root):
        self.root = root
        self.root.title("话题监视器")
        self.root.geometry("1200x700")
        self.root.configure(bg='#f0f0f0')
        
        # 数据存储
        self.online_topics = []  # 在线话题列表
        self.monitor_slots = {}  # 监视槽位 {slot_id: topic_info}
        self.topic_data = {}     # 话题数据缓存
        self.running = True
        
        # 创建GUI
        self.setup_gui()
        
        # 启动后台线程
        self.start_background_threads()
    
    def setup_gui(self):
        """设置GUI界面"""
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 创建左侧在线话题列表
        self.create_online_topics_panel(main_frame)
        
        # 创建监视框区域
        self.create_monitor_panels(main_frame)
    
    def create_online_topics_panel(self, parent):
        """创建左侧在线话题面板"""
        # 左侧框架
        left_frame = tk.Frame(parent, bg='#f0f0f0', width=200)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left_frame.pack_propagate(False)
        
        # 标题
        title_label = tk.Label(left_frame, text="当前存在话题", 
                              font=('微软雅黑', 12, 'bold'), 
                              bg='#f0f0f0')
        title_label.pack(pady=(0, 10))
        
        # 话题列表框
        list_frame = tk.Frame(left_frame, bg='white', relief=tk.SUNKEN, bd=2)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        # 滚动条
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 列表框
        self.topics_listbox = tk.Listbox(list_frame, 
                                        yscrollcommand=scrollbar.set,
                                        font=('微软雅黑', 10),
                                        selectmode=tk.SINGLE)
        self.topics_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.topics_listbox.yview)
        
        # 绑定双击事件
        self.topics_listbox.bind('<Double-Button-1>', self.on_topic_select)
    
    def create_monitor_panels(self, parent):
        """创建监视面板区域"""
        # 右侧框架
        right_frame = tk.Frame(parent, bg='#f0f0f0')
        right_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # 创建10个监视槽位
        self.monitor_frames = {}
        self.status_indicators = {}
        self.frequency_vars = {}
        self.data_displays = {}
        self.control_buttons = {}
        
        for i in range(10):
            self.create_single_monitor_panel(right_frame, i)
    
    def create_single_monitor_panel(self, parent, slot_id):
        """创建单个监视面板"""
        # 主框架
        panel_frame = tk.Frame(parent, bg='white', relief=tk.RAISED, bd=2)
        panel_frame.pack(fill=tk.X, pady=5, padx=5)
        
        # 左侧话题显示框
        topic_frame = tk.Frame(panel_frame, bg='white', width=150)
        topic_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
        topic_frame.pack_propagate(False)
        
        topic_label = tk.Label(topic_frame, text=f"话题槽位 {slot_id + 1}", 
                              font=('微软雅黑', 10),
                              bg='white', relief=tk.SUNKEN, bd=1)
        topic_label.pack(fill=tk.BOTH, expand=True)
        
        # 控制按钮
        btn_frame = tk.Frame(panel_frame, bg='white')
        btn_frame.pack(side=tk.LEFT, padx=5)
        
        control_btn = tk.Button(btn_frame, text="确定", 
                               command=lambda: self.toggle_binding(slot_id),
                               font=('微软雅黑', 9),
                               width=6, height=2)
        control_btn.pack()
        self.control_buttons[slot_id] = control_btn
        
        # 状态指示器（圆形按钮）
        status_frame = tk.Frame(panel_frame, bg='white')
        status_frame.pack(side=tk.LEFT, padx=5)
        
        status_indicator = tk.Label(status_frame, text="●", 
                                   font=('微软雅黑', 20),
                                   fg='gray', bg='white')
        status_indicator.pack()
        self.status_indicators[slot_id] = status_indicator
        
        # 频率设置
        freq_frame = tk.Frame(panel_frame, bg='white')
        freq_frame.pack(side=tk.LEFT, padx=5)
        
        tk.Label(freq_frame, text="频率(Hz):", 
                font=('微软雅黑', 9), bg='white').pack()
        
        freq_var = tk.StringVar(value="1.0")
        freq_entry = tk.Entry(freq_frame, textvariable=freq_var, 
                             width=8, font=('微软雅黑', 9))
        freq_entry.pack()
        self.frequency_vars[slot_id] = freq_var
        
        # 数据显示区域
        data_frame = tk.Frame(panel_frame, bg='white')
        data_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        
        data_text = tk.Text(data_frame, height=3, width=40,
                           font=('Consolas', 9),
                           wrap=tk.WORD, state=tk.DISABLED)
        data_text.pack(fill=tk.BOTH, expand=True)
        self.data_displays[slot_id] = data_text
        
        # 存储引用
        self.monitor_frames[slot_id] = {
            'frame': panel_frame,
            'topic_label': topic_label,
            'bound_topic': None
        }
    
    def on_topic_select(self, event):
        """话题选择事件"""
        selection = self.topics_listbox.curselection()
        if selection:
            topic_name = self.topics_listbox.get(selection[0])
            self.selected_topic = topic_name
            messagebox.showinfo("提示", f"已选择话题: {topic_name}\n请点击要绑定的话题框右侧的'确定'按钮")
    
    def toggle_binding(self, slot_id):
        """切换话题绑定"""
        if self.monitor_frames[slot_id]['bound_topic'] is None:
            # 绑定话题
            if hasattr(self, 'selected_topic'):
                self.bind_topic_to_slot(slot_id, self.selected_topic)
            else:
                messagebox.showwarning("警告", "请先从左侧话题列表中选择一个话题")
        else:
            # 解绑话题
            self.unbind_topic_from_slot(slot_id)
    
    def bind_topic_to_slot(self, slot_id, topic_name):
        """绑定话题到槽位"""
        # 检查是否已经绑定到其他槽位
        for sid, info in self.monitor_frames.items():
            if info['bound_topic'] == topic_name:
                messagebox.showwarning("警告", f"话题 {topic_name} 已经绑定到槽位 {sid + 1}")
                return
        
        # 绑定话题
        self.monitor_frames[slot_id]['bound_topic'] = topic_name
        self.monitor_frames[slot_id]['topic_label'].config(text=topic_name)
        self.control_buttons[slot_id].config(text="取消")
        
        # 初始化监视槽位
        self.monitor_slots[slot_id] = {
            'topic': topic_name,
            'frequency': float(self.frequency_vars[slot_id].get() or 1.0),
            'last_update': time.time(),
            'data_count': 0
        }
        
        messagebox.showinfo("成功", f"话题 {topic_name} 已绑定到槽位 {slot_id + 1}")
    
    def unbind_topic_from_slot(self, slot_id):
        """解绑话题"""
        topic_name = self.monitor_frames[slot_id]['bound_topic']
        
        # 解绑
        self.monitor_frames[slot_id]['bound_topic'] = None
        self.monitor_frames[slot_id]['topic_label'].config(text=f"话题槽位 {slot_id + 1}")
        self.control_buttons[slot_id].config(text="确定")
        self.status_indicators[slot_id].config(fg='gray')
        
        # 清除监视数据
        if slot_id in self.monitor_slots:
            del self.monitor_slots[slot_id]
        
        # 清除数据显示
        self.data_displays[slot_id].config(state=tk.NORMAL)
        self.data_displays[slot_id].delete(1.0, tk.END)
        self.data_displays[slot_id].config(state=tk.DISABLED)
        
        messagebox.showinfo("成功", f"话题 {topic_name} 已从槽位 {slot_id + 1} 解绑")
    
    def update_online_topics(self):
        """更新在线话题列表（模拟）"""
        while self.running:
            try:
                # 模拟发现在线话题
                potential_topics = [
                    "/sensor/camera", "/sensor/lidar", "/robot/pose",
                    "/navigation/goal", "/cmd_vel", "/joint_states",
                    "/map", "/scan", "/odom", "/imu",
                    "/temperature", "/humidity", "/pressure"
                ]
                
                # 随机选择一些话题作为在线话题
                num_online = random.randint(5, 10)
                new_online_topics = random.sample(potential_topics, num_online)
                
                # 更新GUI
                if new_online_topics != self.online_topics:
                    self.online_topics = new_online_topics
                    self.root.after(0, self.refresh_topics_list)
                
                time.sleep(2)  # 每2秒检查一次
            except Exception as e:
                print(f"更新在线话题时出错: {e}")
                time.sleep(1)
    
    def refresh_topics_list(self):
        """刷新话题列表显示"""
        self.topics_listbox.delete(0, tk.END)
        for topic in sorted(self.online_topics):
            self.topics_listbox.insert(tk.END, topic)
    
    def monitor_topics(self):
        """监视话题数据"""
        while self.running:
            try:
                current_time = time.time()
                
                for slot_id, slot_info in self.monitor_slots.copy().items():
                    topic = slot_info['topic']
                    frequency = float(self.frequency_vars[slot_id].get() or 1.0)
                    
                    # 检查是否需要更新
                    if current_time - slot_info['last_update'] >= 1.0 / frequency:
                        # 更新状态指示器
                        is_online = topic in self.online_topics
                        color = 'green' if is_online else 'red'
                        self.root.after(0, lambda sid=slot_id, c=color: 
                                       self.status_indicators[sid].config(fg=c))
                        
                        # 生成模拟数据
                        if is_online:
                            data = self.generate_mock_data(topic)
                            self.root.after(0, lambda sid=slot_id, d=data: 
                                           self.update_data_display(sid, d))
                            
                            slot_info['last_update'] = current_time
                            slot_info['data_count'] += 1
                
                time.sleep(0.1)  # 100ms检查间隔
            except Exception as e:
                print(f"监视话题时出错: {e}")
                time.sleep(1)
    
    def generate_mock_data(self, topic):
        """生成模拟话题数据"""
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        
        if "sensor" in topic:
            value = round(random.uniform(0, 100), 2)
            return f"[{timestamp}] 传感器数据: {value}"
        elif "cmd_vel" in topic:
            linear = round(random.uniform(-2, 2), 2)
            angular = round(random.uniform(-1, 1), 2)
            return f"[{timestamp}] 速度命令: 线速度={linear}, 角速度={angular}"
        elif "pose" in topic:
            x = round(random.uniform(-10, 10), 2)
            y = round(random.uniform(-10, 10), 2)
            return f"[{timestamp}] 位置: x={x}, y={y}"
        else:
            value = round(random.uniform(0, 1000), 2)
            return f"[{timestamp}] 数据: {value}"
    
    def update_data_display(self, slot_id, data):
        """更新数据显示"""
        try:
            text_widget = self.data_displays[slot_id]
            text_widget.config(state=tk.NORMAL)
            
            # 添加新数据
            text_widget.insert(tk.END, data + "\n")
            
            # 限制显示行数（保持最新的10行）
            lines = text_widget.get(1.0, tk.END).strip().split('\n')
            if len(lines) > 10:
                text_widget.delete(1.0, tk.END)
                text_widget.insert(1.0, '\n'.join(lines[-10:]) + '\n')
            
            # 滚动到底部
            text_widget.see(tk.END)
            text_widget.config(state=tk.DISABLED)
        except Exception as e:
            print(f"更新数据显示时出错: {e}")
    
    def start_background_threads(self):
        """启动后台线程"""
        # 话题发现线程
        topic_thread = threading.Thread(target=self.update_online_topics, daemon=True)
        topic_thread.start()
        
        # 数据监视线程
        monitor_thread = threading.Thread(target=self.monitor_topics, daemon=True)
        monitor_thread.start()
    
    def on_closing(self):
        """关闭程序时的清理"""
        self.running = False
        self.root.quit()
        self.root.destroy()


def main():
    """主函数"""
    root = tk.Tk()
    app = TopicMonitor(root)
    
    # 绑定关闭事件
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    
    # 启动GUI
    root.mainloop()


if __name__ == "__main__":
    main()
