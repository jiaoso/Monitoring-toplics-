# MoveIt2运动数据频率详解

## 📊 MoveIt2运动数据频率分析

### 🎯 **核心频率参数**

#### 1. **轨迹规划频率**
- **规划频率**: 通常为 **1-10 Hz**
- **用途**: 计算从起点到终点的轨迹
- **特点**: 不需要很高频率，因为规划是一次性的

#### 2. **轨迹执行频率**
- **控制频率**: **100-1000 Hz** (典型值为 **125-500 Hz**)
- **用途**: 实时跟踪轨迹点，发送关节命令
- **关键**: 这是影响运动平滑度的主要因素

#### 3. **状态反馈频率**
- **关节状态**: **100-1000 Hz** (与控制频率同步)
- **TF变换**: **30-100 Hz** (根据需要)
- **传感器数据**: **10-100 Hz** (取决于传感器类型)

---

## 🔧 **MoveIt2中的关键频率设置**

### 1. **trajectory_execution_manager**
```yaml
# moveit_config/config/moveit_controllers.yaml
trajectory_execution:
  allowed_execution_duration_scaling: 1.2
  allowed_goal_duration_margin: 0.5
  execution_duration_monitoring: false
```

### 2. **控制器频率设置**
```yaml
# ros2_control配置
controller_manager:
  ros__parameters:
    update_rate: 125  # 控制器更新频率 (Hz)
    
joint_trajectory_controller:
  ros__parameters:
    joints: [joint1, joint2, joint3, joint4, joint5, joint6]
    command_interfaces: [position]
    state_interfaces: [position, velocity]
    allow_partial_joints_goal: false
    goal_time: 0.0  # 允许的到达时间误差
```

### 3. **轨迹插值频率**
```yaml
# 轨迹点之间的插值
interpolation_rate: 125  # Hz (与控制器频率匹配)
time_from_start: 0.008   # 8ms间隔 = 125Hz
```

---

## 📈 **实际运动数据频率**

### 🤖 **典型CR5机械臂配置**

#### **控制层频率**:
```
控制器更新: 125-500 Hz   (推荐 250 Hz)
轨迹插值:   125-250 Hz   (与控制器同步)
关节状态:   125-500 Hz   (反馈频率)
```

#### **MoveIt2规划层频率**:
```
规划请求:   1-5 Hz       (用户触发)
轨迹生成:   一次性        (规划完成后)
执行监控:   10-50 Hz     (监控执行状态)
```

### 📊 **数据发布频率对比**

| 话题 | 典型频率 | 最高频率 | 用途 |
|------|----------|----------|------|
| `/joint_states` | 100-500 Hz | 1000 Hz | 关节实时状态 |
| `/tf` | 30-100 Hz | 500 Hz | 坐标变换 |
| `controller/state` | 10-100 Hz | 250 Hz | 控制器状态 |
| `controller/command` | 100-500 Hz | 1000 Hz | 控制指令 |
| `/move_group/display_planned_path` | 1-10 Hz | 50 Hz | 可视化轨迹 |

---

## ⚡ **高频数据采集配置**

### 1. **提高joint_states频率**
```yaml
# robot_description配置
hardware_interface:
  joints:
    - joint1
    - joint2
    # ...
  update_rate: 500  # 提高到500Hz
```

### 2. **优化控制器配置**
```yaml
# joint_trajectory_controller
ros2_control:
  hardware:
    - name: cr5_hardware_interface
      parameters:
        update_rate: 250  # 250Hz控制频率
        state_publish_rate: 250  # 状态发布频率
```

### 3. **实时性配置**
```bash
# 设置实时优先级
sudo sysctl -w kernel.sched_rt_runtime_us=950000
sudo sysctl -w kernel.sched_rt_period_us=1000000

# 启动实时控制器
ros2 launch cr5_moveit_config cr5_moveit.launch.py \
  use_rviz:=true \
  controllers_file:=cr5_controllers_high_freq.yaml
```

---

## 🎯 **针对您的数据收集建议**

### 📊 **当前问题分析**
根据您的数据，发现的问题：
- **采样频率过低**: 1Hz无法捕获快速运动
- **消息丢失**: 网络延迟导致数据缺失
- **时间窗口不足**: 错过运动过程

### 🔧 **优化方案**

#### 1. **提高监视频率**
```python
# 在话题监视器中设置高频率
monitoring_frequencies = {
    '/joint_states': 100,           # 100Hz
    '/tf': 50,                      # 50Hz  
    'controller/state': 50,         # 50Hz
    'controller/command': 100       # 100Hz
}
```

#### 2. **同步多话题监视**
```python
# 同时监视相关话题
synchronized_topics = [
    '/joint_states',
    '/cr5_group_controller/state', 
    '/cr5_group_controller/command',
    '/tf'
]
```

#### 3. **缓冲区优化**
```python
# 增加缓冲区大小，减少丢包
ros2_buffer_size = 1000  # 1000个消息缓冲
network_buffer = "1MB"   # 1MB网络缓冲
```

---

## 💡 **实际运动频率测试**

### 🧪 **测试方法**
```bash
# 1. 测试joint_states频率
ros2 topic hz /joint_states

# 2. 测试控制器频率  
ros2 topic hz /cr5_group_controller/state

# 3. 测试运动期间的数据率
ros2 bag record -a  # 录制所有话题进行分析
```

### 📈 **预期结果**
- **静止状态**: 10-100 Hz (取决于配置)
- **运动期间**: 100-500 Hz (控制器全速运行)
- **轨迹点**: 每8ms一个点 (125Hz)

---

## 🎯 **结论**

MoveIt2的运动数据频率可以达到：

- **最高理论频率**: **1000 Hz** (1ms周期)
- **典型实用频率**: **250-500 Hz** (2-4ms周期)
- **推荐监视频率**: **100-250 Hz** (平衡性能和数据质量)

要捕获完整的运动轨迹，建议将话题监视器频率设置为 **50-100 Hz** 以上！
