#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
话题监视器综合测试脚本
验证所有组件的功能是否正常
"""

import os
import sys
import subprocess
import json
import tempfile
from pathlib import Path

def test_file_exists(filename):
    """测试文件是否存在"""
    return os.path.exists(filename)

def test_python_syntax(filename):
    """测试Python文件语法是否正确"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            compile(f.read(), filename, 'exec')
        return True
    except SyntaxError as e:
        print(f"语法错误 in {filename}: {e}")
        return False
    except Exception as e:
        print(f"其他错误 in {filename}: {e}")
        return False

def test_json_format(filename):
    """测试JSON文件格式是否正确"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            json.load(f)
        return True
    except json.JSONDecodeError as e:
        print(f"JSON格式错误 in {filename}: {e}")
        return False
    except Exception as e:
        print(f"其他错误 in {filename}: {e}")
        return False

def test_script_executable(filename):
    """测试脚本是否可执行"""
    return os.access(filename, os.X_OK)

def run_tests():
    """运行所有测试"""
    print("话题监视器系统测试")
    print("=" * 50)
    
    # 定义要测试的文件
    test_files = {
        'Python脚本': [
            'topic_monitor.py',
            'enhanced_topic_monitor.py',
            'real_topic_monitor.py',
            'demo.py',
            'data_exporter.py'
        ],
        '配置文件': [
            'example_config.json'
        ],
        '脚本文件': [
            'start_monitor.sh',
            'run_monitor.sh'
        ],
        '文档文件': [
            'README.md'
        ]
    }
    
    test_results = {}
    total_tests = 0
    passed_tests = 0
    
    # 文件存在性测试
    print("\n1. 文件存在性测试")
    print("-" * 30)
    for category, files in test_files.items():
        print(f"\n{category}:")
        for filename in files:
            total_tests += 1
            exists = test_file_exists(filename)
            result = "✓ 通过" if exists else "✗ 失败"
            print(f"  {filename:<30} {result}")
            if exists:
                passed_tests += 1
    
    # Python语法测试
    print("\n\n2. Python语法测试")
    print("-" * 30)
    for filename in test_files['Python脚本']:
        if test_file_exists(filename):
            total_tests += 1
            syntax_ok = test_python_syntax(filename)
            result = "✓ 通过" if syntax_ok else "✗ 失败"
            print(f"  {filename:<30} {result}")
            if syntax_ok:
                passed_tests += 1
    
    # JSON格式测试
    print("\n\n3. JSON格式测试")
    print("-" * 30)
    for filename in test_files['配置文件']:
        if test_file_exists(filename):
            total_tests += 1
            json_ok = test_json_format(filename)
            result = "✓ 通过" if json_ok else "✗ 失败"
            print(f"  {filename:<30} {result}")
            if json_ok:
                passed_tests += 1
    
    # 脚本可执行性测试
    print("\n\n4. 脚本可执行性测试")
    print("-" * 30)
    for filename in test_files['脚本文件']:
        if test_file_exists(filename):
            total_tests += 1
            executable = test_script_executable(filename)
            result = "✓ 通过" if executable else "✗ 失败"
            print(f"  {filename:<30} {result}")
            if executable:
                passed_tests += 1
    
    # 功能测试
    print("\n\n5. 功能模块导入测试")
    print("-" * 30)
    
    # 测试数据导出器
    try:
        total_tests += 1
        sys.path.append('.')
        from data_exporter import TopicDataExporter
        exporter = TopicDataExporter()
        print(f"  数据导出器模块               ✓ 通过")
        passed_tests += 1
    except Exception as e:
        print(f"  数据导出器模块               ✗ 失败: {e}")
    
    # 测试配置加载
    try:
        total_tests += 1
        with open('example_config.json', 'r') as f:
            config = json.load(f)
        if 'bindings' in config and 'frequencies' in config:
            print(f"  配置文件结构                 ✓ 通过")
            passed_tests += 1
        else:
            print(f"  配置文件结构                 ✗ 失败: 缺少必要字段")
    except Exception as e:
        print(f"  配置文件结构                 ✗ 失败: {e}")
    
    # 测试总结
    print("\n\n测试总结")
    print("=" * 50)
    print(f"总测试数: {total_tests}")
    print(f"通过测试: {passed_tests}")
    print(f"失败测试: {total_tests - passed_tests}")
    print(f"通过率: {(passed_tests/total_tests*100):.1f}%")
    
    if passed_tests == total_tests:
        print("\n🎉 所有测试通过！系统可以正常使用。")
        return True
    else:
        print(f"\n⚠️  有 {total_tests - passed_tests} 个测试失败，请检查相关文件。")
        return False

def show_usage_info():
    """显示使用信息"""
    print("\n使用说明")
    print("=" * 50)
    print("1. 启动监视器:")
    print("   ./start_monitor.sh          # 交互式启动")
    print("   python3 real_topic_monitor.py      # 直接启动真实版（推荐）")
    print("   python3 enhanced_topic_monitor.py  # 直接启动增强版")
    print("   python3 topic_monitor.py    # 直接启动基础版")
    print()
    print("2. 运行演示:")
    print("   python3 demo.py")
    print()
    print("3. 数据导出:")
    print("   python3 data_exporter.py")
    print()
    print("4. 查看文档:")
    print("   cat README.md")

def main():
    """主函数"""
    success = run_tests()
    
    if success:
        show_usage_info()
        
        choice = input("\n是否现在启动演示? (y/n): ").lower()
        if choice == 'y':
            try:
                subprocess.run([sys.executable, 'demo.py'])
            except KeyboardInterrupt:
                print("\n演示被用户中断")
            except Exception as e:
                print(f"启动演示失败: {e}")
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
