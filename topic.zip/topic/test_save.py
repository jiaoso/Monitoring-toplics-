#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试保存功能的简单脚本
"""

import os
import time
from datetime import datetime

def test_save_function():
    """测试保存功能"""
    save_directory = "话题信息存储"
    
    # 确保目录存在
    os.makedirs(save_directory, exist_ok=True)
    
    # 测试文件名生成
    topic_name = "/test/topic"
    topic_short = topic_name.replace('/', '_').replace(' ', '_')
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{topic_short}_{timestamp}.txt"
    filepath = os.path.join(save_directory, filename)
    
    print(f"测试保存功能...")
    print(f"话题名称: {topic_name}")
    print(f"文件路径: {filepath}")
    
    try:
        # 创建测试文件
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"话题数据保存文件\n")
            f.write(f"话题名称: {topic_name}\n")
            f.write(f"开始时间: {datetime.now().isoformat()}\n")
            f.write(f"{'='*50}\n\n")
        
        print("✓ 文件创建成功")
        
        # 写入测试数据
        for i in range(5):
            test_data = f"[{datetime.now().strftime('%H:%M:%S.%f')[:-3]}] 测试数据 {i+1}: 数值={i*2.5}"
            with open(filepath, 'a', encoding='utf-8') as f:
                f.write(test_data + '\n')
            print(f"✓ 写入数据: {test_data}")
            time.sleep(0.5)
        
        # 写入结束信息
        with open(filepath, 'a', encoding='utf-8') as f:
            f.write(f"\n{'='*50}\n")
            f.write(f"结束时间: {datetime.now().isoformat()}\n")
            f.write(f"总消息数: 5\n")
        
        print("✓ 测试完成")
        print(f"✓ 文件已保存: {filepath}")
        
        # 读取并显示文件内容
        print("\n文件内容:")
        print("-" * 40)
        with open(filepath, 'r', encoding='utf-8') as f:
            print(f.read())
        
        return True
        
    except Exception as e:
        print(f"✗ 测试失败: {e}")
        return False

if __name__ == "__main__":
    test_save_function()
