#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
话题数据生成器 - 用于测试真实话题监视器
生成模拟的ROS话题数据，方便测试监视器功能
"""

import subprocess
import time
import json
import os
from datetime import datetime


def create_test_topic_file(topic_name, data_type="sensor_msgs/String"):
    """创建测试话题数据文件"""
    filename = f"test_topic_{topic_name.replace('/', '_')}.py"
    
    script_content = f'''#!/usr/bin/env python3
import time
import json
from datetime import datetime

# 模拟话题: {topic_name}
# 数据类型: {data_type}

print("开始发布话题数据: {topic_name}")
print("数据类型: {data_type}")
print("按 Ctrl+C 停止")

try:
    counter = 0
    while True:
        timestamp = datetime.now().isoformat()
        
        if "sensor" in "{topic_name}":
            data = {{
                "header": {{
                    "stamp": timestamp,
                    "frame_id": "base_link"
                }},
                "data": f"传感器数据 {{counter}} - 时间: {{timestamp}}"
            }}
        elif "cmd_vel" in "{topic_name}":
            data = {{
                "linear": {{
                    "x": 1.0 + (counter % 10) * 0.1,
                    "y": 0.0,
                    "z": 0.0
                }},
                "angular": {{
                    "x": 0.0,
                    "y": 0.0,
                    "z": 0.5 + (counter % 5) * 0.1
                }}
            }}
        else:
            data = {{
                "timestamp": timestamp,
                "message": f"话题数据 {{counter}}",
                "value": counter * 2.5
            }}
        
        print(f"[{{datetime.now().strftime('%H:%M:%S')}}] {topic_name}: {{json.dumps(data, ensure_ascii=False)}}")
        
        counter += 1
        time.sleep(1)  # 1Hz频率
        
except KeyboardInterrupt:
    print("\\n话题发布已停止")
'''
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(script_content)
    
    # 添加执行权限
    os.chmod(filename, 0o755)
    return filename


def main():
    """主函数"""
    print("话题数据生成器")
    print("=" * 40)
    
    # 创建测试话题
    test_topics = [
        ("/test/sensor_data", "sensor_msgs/String"),
        ("/test/cmd_vel", "geometry_msgs/Twist"), 
        ("/test/robot_status", "std_msgs/String"),
        ("/test/camera_info", "sensor_msgs/CameraInfo")
    ]
    
    print("创建测试话题脚本...")
    created_files = []
    
    for topic_name, data_type in test_topics:
        filename = create_test_topic_file(topic_name, data_type)
        created_files.append((filename, topic_name))
        print(f"✓ 创建 {filename} -> {topic_name}")
    
    print(f"\\n共创建 {len(created_files)} 个测试话题脚本")
    print("\\n使用方法:")
    print("1. 在单独的终端中运行这些脚本来模拟话题数据")
    print("2. 启动真实话题监视器来监视这些'话题'")
    print("3. 测试保存功能")
    
    print("\\n示例:")
    for filename, topic_name in created_files:
        print(f"  python3 {filename}  # 模拟 {topic_name}")
    
    print("\\n注意: 这些脚本模拟话题数据输出，不是真正的ROS话题")
    print("如果有ROS环境，建议使用真实的ROS话题进行测试")
    
    choice = input("\\n是否现在运行第一个测试话题? (y/n): ").lower()
    if choice == 'y' and created_files:
        print(f"\\n启动 {created_files[0][1]} 话题模拟器...")
        try:
            subprocess.run(['python3', created_files[0][0]])
        except KeyboardInterrupt:
            print("\\n测试话题已停止")


if __name__ == "__main__":
    main()
