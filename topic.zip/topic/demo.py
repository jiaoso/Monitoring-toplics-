#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
话题监视器演示脚本
自动展示监视器的各种功能
"""

import time
import subprocess
import sys
import os

def print_header(title):
    """打印标题"""
    print("\n" + "="*50)
    print(f"  {title}")
    print("="*50)

def print_step(step, description):
    """打印步骤"""
    print(f"\n[步骤 {step}] {description}")
    time.sleep(1)

def main():
    """演示主函数"""
    print_header("话题监视器演示")
    
    print("这个演示将展示话题监视器的功能特性")
    print("演示内容包括:")
    print("1. 基础功能介绍")
    print("2. 配置文件使用")
    print("3. 实际运行效果")
    
    input("\n按回车键开始演示...")
    
    # 检查文件
    print_step(1, "检查文件结构")
    files = [
        "topic_monitor.py",
        "enhanced_topic_monitor.py", 
        "start_monitor.sh",
        "example_config.json",
        "README.md"
    ]
    
    for file in files:
        if os.path.exists(file):
            print(f"✓ {file}")
        else:
            print(f"✗ {file} (缺失)")
    
    print_step(2, "显示示例配置")
    try:
        with open("example_config.json", "r", encoding="utf-8") as f:
            config_content = f.read()
        print("示例配置内容:")
        print(config_content)
    except Exception as e:
        print(f"读取配置文件失败: {e}")
    
    print_step(3, "功能特性说明")
    features = [
        "✓ 最多监视10个话题",
        "✓ 实时状态指示器 (绿色=在线, 红色=离线)",
        "✓ 可调监视频率 (每个槽位独立设置)",
        "✓ 实时数据显示和滚动更新",
        "✓ 配置保存和加载功能",
        "✓ 话题搜索和过滤",
        "✓ 统计信息和消息计数",
        "✓ 多线程后台监控"
    ]
    
    for feature in features:
        print(f"  {feature}")
        time.sleep(0.3)
    
    print_step(4, "启动选项")
    print("可以通过以下方式启动:")
    print("1. ./start_monitor.sh    (交互式选择)")
    print("2. python3 topic_monitor.py    (基础版)")
    print("3. python3 enhanced_topic_monitor.py    (增强版)")
    
    choice = input("\n是否现在启动增强版监视器? (y/n): ").lower()
    
    if choice == 'y':
        print_step(5, "启动增强版话题监视器")
        print("正在启动GUI应用...")
        try:
            subprocess.run([sys.executable, "enhanced_topic_monitor.py"])
        except KeyboardInterrupt:
            print("\n用户中断了程序")
        except Exception as e:
            print(f"启动失败: {e}")
    else:
        print("\n演示结束。您可以随时运行:")
        print("  python3 enhanced_topic_monitor.py")
        print("\n查看完整文档请参考 README.md")

if __name__ == "__main__":
    main()
