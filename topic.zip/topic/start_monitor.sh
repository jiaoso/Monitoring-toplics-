#!/bin/bash
# 话题监视器启动脚本

echo "话题监视器启动选择:"
echo "1. 基础版本 (topic_monitor.py) - 模拟数据"
echo "2. 增强版本 (enhanced_topic_monitor.py) - 模拟数据"
echo "3. 真实话题版本 (real_topic_monitor.py) - 推荐"
echo ""
read -p "请选择版本 (1-3): " choice

case $choice in
    1)
        echo "启动基础版话题监视器..."
        python3 topic_monitor.py
        ;;
    2)
        echo "启动增强版话题监视器..."
        python3 enhanced_topic_monitor.py
        ;;
    3)
        echo "启动真实话题监视器..."
        python3 real_topic_monitor.py
        ;;
    *)
        echo "无效选择，启动真实话题监视器..."
        python3 real_topic_monitor.py
        ;;
esac
