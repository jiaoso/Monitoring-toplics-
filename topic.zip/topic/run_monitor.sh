#!/bin/bash
# 话题监视器启动脚本

echo "启动话题监视器..."
python3 topic_monitor.py
